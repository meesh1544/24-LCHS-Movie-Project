from flask import Flask, request, redirect, render_template, session
import sqlite3

app = Flask(__name__)
app.config['DEBUG'] = True
app.secret_key = 'K>~EEAnH_x,Z{q.43;NmyQiNz1^Yr7'

def execute_query(query_string):
  db = sqlite3.connect('project.db')
  cursor = db.cursor()
  try:
      if "select" in query_string.lower():
          results = list(cursor.execute(query_string))
      else:
          cursor.execute(query_string)
          db.commit()
          results = "success"
  except Exception as e:
      print(f"An error occurred: {e}")
      results = 'error'
  db.close()
  return results
  
@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        # Collect the table choice from the form. Store it in a session cookie.
        session['table'] = request.form['table']

        # Based on the table choice, assign the column names to the session.
        # These will be displayed on each of the other the web forms.
        if session['table'] == 'movies':
            session['columns'] = ['movie_id', 'title', 'year_released', 'director']
        else:
            session['columns'] = ['director_id', 'last_name', 'first_name']

        # Request the chosen SQL option from the form, and use it to build the query_type string.
        query_type = '/' + request.form['query_type'].lower()

        # Use the query_type string to redirect control to the proper function.
        return redirect(query_type)
    else:
        # The query_types list is used to create the labels for the form on the home page.
        query_types = ['INSERT', 'SELECT', 'UPDATE', 'DELETE']
        
        # Remove old data from the session cookie.
        session.clear()

    return render_template("index.html", tab_title = "Movie SQL Project", query_types = query_types, home = True)

@app.route('/insert', methods=['GET', 'POST'])
def insert_query():
  if request.method == 'POST':
    # Collect the values from the form.
    new_values = request.form['new_values']
    # Collect the table name from the session.
    table = session['table']

    # Build the SQL query using the collected values.
    sql_query = f"INSERT INTO {table} ({session['columns']}) VALUES ({new_values})"

  else:
    # Initialize the SQL query variable as an empty string for GET requests.
    sql_query = ''

  # Render the insert.html template, passing the generated SQL query.
  return render_template("insert.html", tab_title = "INSERT query", home = False, sql_query = sql_query)

@app.route('/select', methods=['GET', 'POST'])
def select_query():
   if request.method == 'POST':
      table = session['table']
      columns = request.form['columns']
      condition = request.form['condition']
      sql_query = f"SELECT {columns} FROM {table}"
      if condition != '':
         sql_query += f" WHERE {condition}"

      # Here's the 4 lines of new code!
      if columns == '*':
         session['selected_columns'] = session['columns'].copy()
      else:
         session['selected_columns'] = columns.split(',')

      results = execute_query(sql_query)

@app.route('/update', methods=['GET', 'POST'])
def update_query():
  if request.method == 'POST':
    # Collect the SET value from the form.
    new_value = request.form['new_value']
    # Collect the condition from the form.
    condition = request.form['condition']
    # Collect the table name from the session.
    table = session['table']

    # Build the SQL query using the collected values.
    sql_query = f"UPDATE {table} SET {new_value}"
    if condition != '':
      sql_query += f" WHERE {condition}"

  else:
    # Initialize the SQL query variable as an empty string for GET requests.
    sql_query = ''

  # Render the update.html template, passing the generated SQL query.
  return render_template("update.html", tab_title = "UPDATE query", home = False, sql_query = sql_query)

der_template("update.html", tab_title = "UPDATE query", home = False)

@app.route('/delete', methods=['GET', 'POST'])
def delete_query():
   if request.method == 'POST':
      condition = request.form['condition']
      table = session['table']
      sql_query = f"DELETE FROM {table} WHERE {condition}"
   else:
      sql_query = ''

   return render_template('delete.html', tab_title = 'DELETE query',
      home = False, sql_query = sql_query)
if __name__ == '__main__':
    app.run()